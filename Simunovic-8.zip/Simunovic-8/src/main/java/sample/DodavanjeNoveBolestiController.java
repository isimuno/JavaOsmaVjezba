package sample;

import covidportal.main.GlavnaDatoteke;
import covidportal.model.Bolest;
import covidportal.model.Simptom;
import covidportal.model.Zupanija;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.paint.Color;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DodavanjeNoveBolestiController {

    @FXML
    private TextField nazivBolesti;
    @FXML
    private Label idBolesti;
    @FXML
    ListView<String> listView;

    Long maxID = Long.valueOf(0);
    List<Simptom> listaSimptoma  = new ArrayList<>();
    List<String> listaNazivaSimptoma = new ArrayList<>();
    List<Bolest> listaBolesti  = new ArrayList<>();

    public void initialize() throws IOException {
        listaBolesti = GlavnaDatoteke.dohvatiBolesti();
        for(int i =0; i < listaBolesti.size();i++) {
            if(Integer.parseInt(listaBolesti.get(i).getId().toString()) > maxID) {
                maxID = listaBolesti.get(i).getId();
            }
            else {
                continue;
            }
        }

        listaSimptoma = GlavnaDatoteke.dohvatiSimptome();
        for(Simptom s: listaSimptoma){
            listaNazivaSimptoma.add(s.getNaziv());
        }
        ObservableList<String> items = FXCollections.observableArrayList(listaNazivaSimptoma);
        listView.setItems(items);
        listView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        Label label = new Label();
        label.setTextFill(Color.RED);

        listView.getSelectionModel().selectedItemProperty()
                .addListener((ObservableValue<? extends String> ov, String old_val, String new_val) -> {
                  ObservableList<String> selectedItems = listView.getSelectionModel().getSelectedItems();

                    StringBuilder builder = new StringBuilder("Selected items :");

                    for (String name : selectedItems) {
                        builder.append(name + "\n");
                    }

                    label.setText(builder.toString());

                });
        idBolesti.setText(String.valueOf(maxID+10));
    }
    public void dodajNovuBolest() throws IOException {
        listaBolesti = GlavnaDatoteke.dohvatiBolesti();
        StringBuffer pogreskaPoruka = new StringBuffer();

        if(nazivBolesti.getText().isBlank() || listView.getSelectionModel().isEmpty()) {
            if(nazivBolesti.getText().isBlank()  && listView.getSelectionModel().isEmpty()) {
                Alert alertPoruka = new Alert(Alert.AlertType.INFORMATION);
                alertPoruka.setTitle("Pogreska prilikom unosa !");
                alertPoruka.setHeaderText("Niste unijeli podatke !");
                alertPoruka.setContentText("Molimo popunite sva polja prilikom unosa !");
                alertPoruka.showAndWait();
            }
            else if(nazivBolesti.getText().isBlank()) {
                pogreskaPoruka.append("Niste unijeli naziv bolesti!");
                Alert alertPoruka = new Alert(Alert.AlertType.INFORMATION);
                alertPoruka.setTitle("Pogreska prilikom unosa !");
                alertPoruka.setHeaderText("Niste unijeli naziv bolesti!");
                alertPoruka.setContentText("Molimo popunite sva polja prilikom unosa !");
                alertPoruka.showAndWait();}

            else if(listView.getSelectionModel().isEmpty()) {
                pogreskaPoruka.append("Niste odabrali simptome bolesti!");
                Alert alertPoruka = new Alert(Alert.AlertType.INFORMATION);
                alertPoruka.setTitle("Pogreska prilikom unosa !");
                alertPoruka.setHeaderText("Niste unijeli niti jedan simptom!");
                alertPoruka.setContentText("Molimo popunite sva polja prilikom unosa !");
                alertPoruka.showAndWait();}
        }
        else {
            List<String> listaNazivaSimptoma=new ArrayList<>();
            List<Integer> listaIndexaSimptoma=new ArrayList<>();
            maxID +=10;
            FileWriter fw = new FileWriter("dat/bolesti.txt", true);
            fw.write("\n");
            fw.write((maxID).toString());
            fw.write("\n");
            fw.write(nazivBolesti.getText().toUpperCase(Locale.ROOT));
            fw.write("\n");
            for(int i=0; i< listView.getSelectionModel().getSelectedItems().size();i++){
                listaNazivaSimptoma.add(listView.getSelectionModel().getSelectedItems().get(i).toString());
                System.out.println("U listunazivaSimptoma dodan: " + listView.getSelectionModel().getSelectedItems().get(i).toString());
            }
            for(int i=0;i<listaNazivaSimptoma.size();i++){
                for(Simptom s:listaSimptoma){
                    if(s.getNaziv().equals(listaNazivaSimptoma.get(i))){
                        listaIndexaSimptoma.add(s.getId().intValue());
                    }
                }
            }
            for(int i=0; i<listaIndexaSimptoma.size();i++){
                fw.write(listaIndexaSimptoma.get(i).toString());
                if(i<listaIndexaSimptoma.size()-1){
                    fw.write(",");
                }
            }
            fw.close();
            Alert alertPoruka = new Alert(Alert.AlertType.INFORMATION);
            alertPoruka.setTitle("Uspješno se dodali bolest!");
            alertPoruka.setHeaderText("Bolest "+ nazivBolesti.getText() + " je uspješno dodana!");
            alertPoruka.setContentText("Uspješno dodana bolest: " +"\n"
                    +"Naziv: "+ nazivBolesti.getText() + "\n"
                    +"Simptomi: "+ listView.getSelectionModel().getSelectedItems().toString());
            alertPoruka.showAndWait();
            initialize();
            nazivBolesti.setText("");
        }


    }

}
