package sample;

import covidportal.main.GlavnaDatoteke;
import covidportal.model.Bolest;
import covidportal.model.Simptom;
import covidportal.model.Virus;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.paint.Color;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DodavanjeNovogVirusaController {

    @FXML
    private TextField nazivVirusa;
    @FXML
    private Label idVirusa;
    @FXML
    ListView<String> listViewVirusa;


    Long maxID = Long.valueOf(0);
    List<Simptom> listaSimptoma  = new ArrayList<>();
    List<String> listaNazivaSimptoma = new ArrayList<>();
    List<Virus> listaVirusa  = new ArrayList<>();

    public void initialize() throws IOException {
        listaVirusa = GlavnaDatoteke.dohvatiViruse();
        for(int i =0; i < listaVirusa.size();i++) {
            if(Integer.parseInt(listaVirusa.get(i).getId().toString()) > maxID) {
                maxID = listaVirusa.get(i).getId();
            }
            else {
                continue;
            }
        }

        listaSimptoma = GlavnaDatoteke.dohvatiSimptome();
        for(Simptom s: listaSimptoma){
            listaNazivaSimptoma.add(s.getNaziv());
        }
        ObservableList<String> items = FXCollections.observableArrayList(listaNazivaSimptoma);
        listViewVirusa.setItems(items);
        listViewVirusa.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        Label label = new Label();
        label.setTextFill(Color.RED);

        listViewVirusa.getSelectionModel().selectedItemProperty()
                .addListener((ObservableValue<? extends String> ov, String old_val, String new_val) -> {
                    ObservableList<String> selectedItems = listViewVirusa.getSelectionModel().getSelectedItems();

                    StringBuilder builder = new StringBuilder("Selected items :");

                    for (String name : selectedItems) {
                        builder.append(name + "\n");
                    }

                    label.setText(builder.toString());

                });
        idVirusa.setText(String.valueOf(maxID+1));
    }
    public void dodajNoviVirus() throws IOException {
        listaVirusa = GlavnaDatoteke.dohvatiViruse();
        StringBuffer pogreskaPoruka = new StringBuffer();

        if(nazivVirusa.getText().isBlank() || listViewVirusa.getSelectionModel().isEmpty()) {
            if(nazivVirusa.getText().isBlank()  && listViewVirusa.getSelectionModel().isEmpty()) {
                Alert alertPoruka = new Alert(Alert.AlertType.INFORMATION);
                alertPoruka.setTitle("Pogreska prilikom unosa !");
                alertPoruka.setHeaderText("Niste unijeli podatke !");
                alertPoruka.setContentText("Molimo popunite sva polja prilikom unosa !");
                alertPoruka.showAndWait();
            }
            else if(nazivVirusa.getText().isBlank()) {
                pogreskaPoruka.append("Niste unijeli naziv virusa!");
                Alert alertPoruka = new Alert(Alert.AlertType.INFORMATION);
                alertPoruka.setTitle("Pogreska prilikom unosa !");
                alertPoruka.setHeaderText("Niste unijeli naziv virusa!");
                alertPoruka.setContentText("Molimo popunite sva polja prilikom unosa !");
                alertPoruka.showAndWait();}

            else if(listViewVirusa.getSelectionModel().isEmpty()) {
                pogreskaPoruka.append("Niste odabrali simptome virusa!");
                Alert alertPoruka = new Alert(Alert.AlertType.INFORMATION);
                alertPoruka.setTitle("Pogreska prilikom unosa !");
                alertPoruka.setHeaderText("Niste unijeli niti jedan simptom!");
                alertPoruka.setContentText("Molimo popunite sva polja prilikom unosa !");
                alertPoruka.showAndWait();}
        }
        else {
            List<String> listaNazivaSimptoma=new ArrayList<>();
            List<Integer> listaIndexaSimptoma=new ArrayList<>();
            maxID +=1;
            FileWriter fw = new FileWriter("dat/virusi.txt", true);
            fw.write("\n");
            fw.write((maxID).toString());
            fw.write("\n");
            fw.write(nazivVirusa.getText().toUpperCase(Locale.ROOT));
            fw.write("\n");
            for(int i=0; i< listViewVirusa.getSelectionModel().getSelectedItems().size();i++){
                listaNazivaSimptoma.add(listViewVirusa.getSelectionModel().getSelectedItems().get(i).toString());
            }
            for(int i=0;i<listaNazivaSimptoma.size();i++){
                for(Simptom s:listaSimptoma){
                    if(s.getNaziv().equals(listaNazivaSimptoma.get(i))){
                        listaIndexaSimptoma.add(s.getId().intValue());
                    }
                }
            }
            for(int i=0; i<listaIndexaSimptoma.size();i++){
                fw.write(listaIndexaSimptoma.get(i).toString());
                if(i<listaIndexaSimptoma.size()-1){
                    fw.write(",");
                }
            }
            fw.close();
            Alert alertPoruka = new Alert(Alert.AlertType.INFORMATION);
            alertPoruka.setTitle("Uspješno se dodali virus!");
            alertPoruka.setHeaderText("Virus "+ nazivVirusa.getText() + " je uspješno dodana!");
            alertPoruka.setContentText("Uspješno dodan virus: " +"\n"
                    +"Naziv: "+ nazivVirusa.getText() + "\n"
                    +"Simptomi: "+ listViewVirusa.getSelectionModel().getSelectedItems().toString());
            alertPoruka.showAndWait();
            initialize();
            nazivVirusa.setText("");
        }


    }

}
